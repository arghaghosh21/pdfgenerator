package com.gpch.pdfgenerator.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FinalInvoiceModel {
	
	private String invoiceNo;
	private String date;
	private String cname;
	private String caddress;
	private String cgstno;
	private List<ItemModel> items;
	private Double totalCgst;
	private Double totalSgst;
	private Double total;
	private Double totalvbt;
	private Double totalNop;
	private Double totqty;
	private String paymentMode;
	
	

}
