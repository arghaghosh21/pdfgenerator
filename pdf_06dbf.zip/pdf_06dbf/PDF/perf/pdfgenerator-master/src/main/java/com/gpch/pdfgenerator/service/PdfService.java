package com.gpch.pdfgenerator.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gpch.pdfgenerator.model.FinalInvoiceModel;
import com.lowagie.text.DocumentException;

@Service
public class PdfService {

    private static final String PDF_RESOURCES = "/pdf-resources/";
    private SpringTemplateEngine templateEngine;

    @Autowired
    public PdfService( SpringTemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }


    public File generateInvoicePdf(String invoiceNo) throws IOException, DocumentException {
        Context context = getContextInvoice(invoiceNo);
        String html = loadAndFillTemplateInvoice(context);
        return renderPdf(html);
    }

    private File renderPdf(String html) throws IOException, DocumentException {
        File file = File.createTempFile("invoices", ".pdf");
        OutputStream outputStream = new FileOutputStream(file);
        ITextRenderer renderer = new ITextRenderer(20f * 4f / 3f, 20);
        renderer.setDocumentFromString(html, new ClassPathResource(PDF_RESOURCES).getURL().toExternalForm());
        renderer.layout();
        renderer.createPDF(outputStream);
        outputStream.close();
        file.deleteOnExit();
        return file;
    }

    private Context getContextInvoice(String invoiceNo) {
    	
        Context context = new Context();
        try
    	{
        Path path = Paths.get("D:\\PDF\\perf\\pdfgenerator-master\\src\\main\\resources\\pdf-resources\\invoices");
        List<Path> result = findByFileName(path, invoiceNo+".json");
        System.out.println(result.get(0).toFile());
        ObjectMapper mapper= new ObjectMapper();
        FinalInvoiceModel invoice = mapper.readValue(result.get(0).toFile(), FinalInvoiceModel.class);
        context.setVariable("invoice", invoice);
    	}
    	catch(Exception e)
    	{
    	
    	}
        return context;
    }
    

    private String loadAndFillTemplateInvoice(Context context) {
        return templateEngine.process("pdf_invoice", context);
    }
    
    public static List<Path> findByFileName(Path path, String fileName)
            throws IOException {

        List<Path> result;
        try (Stream<Path> pathStream = Files.find(path,
                1,
                (p, basicFileAttributes) ->
                        p.getFileName().toString().equalsIgnoreCase(fileName))
        ) {
            result = pathStream.collect(Collectors.toList());
        }
        return result;

    }

}
