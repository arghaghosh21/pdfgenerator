package com.gpch.pdfgenerator.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.gpch.pdfgenerator.service.InvoiceService;
import com.gpch.pdfgenerator.service.PdfService;
import com.lowagie.text.DocumentException;

@Controller
public class StudentController {

    private final PdfService pdfService;
    private final InvoiceService invoiceService;
    

    @Autowired
    public StudentController(PdfService pdfService , InvoiceService invoiceService) {
        this.pdfService = pdfService;
        this.invoiceService=invoiceService;
        }

    
    @GetMapping("/getInvoices")
    public ModelAndView invoiceView(ModelAndView modelAndView) throws IOException, ParseException {
    	modelAndView.addObject("invoices", invoiceService.getInvoices());
        modelAndView.setViewName("invoices");
        return modelAndView;
    }

    
    @GetMapping("/download-pdf/{invoiceNo}")
    public void downloadPDFInvoice(@PathVariable String invoiceNo ,HttpServletResponse response) {
        try {
            Path file = Paths.get(pdfService.generateInvoicePdf(invoiceNo).getAbsolutePath());
            if (Files.exists(file)) {
                response.setContentType("application/pdf");
                response.addHeader("Content-Disposition",
                        "attachment; filename=" + file.getFileName());
                Files.copy(file, response.getOutputStream());
                response.getOutputStream().flush();
            }
        } catch (DocumentException | IOException ex) {
            ex.printStackTrace();
        }
    }
}
