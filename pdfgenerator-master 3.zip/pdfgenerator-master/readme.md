# PDF Generator

## Getting Started

1. ./mvnw clean install
2. java -jar target/pdfgenerator-0.0.1-SNAPSHOT.jar
3. http://localhost:8080/students
4. Click on "Download PDF Document"

