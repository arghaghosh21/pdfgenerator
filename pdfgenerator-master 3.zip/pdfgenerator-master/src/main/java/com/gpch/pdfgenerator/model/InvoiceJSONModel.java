
package com.gpch.pdfgenerator.model;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"PRINT",
"DUEDT",
"DN_DISCRT",
"A_DISCRT",
"SGSTRT",
"ITNM",
"CO_CODE",
"RETURNED",
"DN_NOFUNIT",
"REFERNAME",
"PMTERMS",
"TCOST",
"UNITOFMESU",
"HSN",
"CGSTRT",
"NOOFUNIT",
"TOUTCGST",
"TAXAMT",
"REBATERT",
"OUTPUTVAT",
"DISCOUNT",
"SHIP_ADDRE",
"RETURN_QTY",
"INVOICEDT",
"ADDRESS",
"PKSIZE",
"OUTPUTSGST",
"A_SGST",
"ITEMNM",
"OUTPUTCGST",
"DN_CGST",
"A_CGST",
"ITCODE",
"TOUTPUTVAT",
"A_TAXAMT",
"TOUTSGST",
"PNAME",
"VATRT",
"SP",
"BATCHNO",
"DN_TAXAMT",
"INVOICENO",
"DN_SGST",
"PRTYNAME",
"REFERCOD",
"BRECNO_C",
"BRECNO",
"A_TCOST",
"NETRATE",
"TDISCOUNT",
"REBATE",
"DN_TCOST"
})
@Generated("jsonschema2pojo")
public class InvoiceJSONModel {

@JsonProperty("PRINT")
private Integer print;
@JsonProperty("DUEDT")
private String duedt;
@JsonProperty("DN_DISCRT")
private Integer dnDiscrt;
@JsonProperty("A_DISCRT")
private Integer aDiscrt;
@JsonProperty("SGSTRT")
private Integer sgstrt;
@JsonProperty("ITNM")
private String itnm;
@JsonProperty("CO_CODE")
private String coCode;
@JsonProperty("RETURNED")
private Integer returned;
@JsonProperty("DN_NOFUNIT")
private Integer dnNofunit;
@JsonProperty("REFERNAME")
private String refername;
@JsonProperty("PMTERMS")
private String pmterms;
@JsonProperty("TCOST")
private Integer tcost;
@JsonProperty("UNITOFMESU")
private String unitofmesu;
@JsonProperty("HSN")
private String hsn;
@JsonProperty("CGSTRT")
private Integer cgstrt;
@JsonProperty("NOOFUNIT")
private Integer noofunit;
@JsonProperty("TOUTCGST")
private Double toutcgst;
@JsonProperty("TAXAMT")
private Integer taxamt;
@JsonProperty("REBATERT")
private Integer rebatert;
@JsonProperty("OUTPUTVAT")
private Integer outputvat;
@JsonProperty("DISCOUNT")
private Integer discount;
@JsonProperty("SHIP_ADDRE")
private String shipAddre;
@JsonProperty("RETURN_QTY")
private Integer returnQty;
@JsonProperty("INVOICEDT")
private String invoicedt;
@JsonProperty("ADDRESS")
private String address;
@JsonProperty("PKSIZE")
private Double pksize;
@JsonProperty("OUTPUTSGST")
private Double outputsgst;
@JsonProperty("A_SGST")
private Integer aSgst;
@JsonProperty("ITEMNM")
private String itemnm;
@JsonProperty("OUTPUTCGST")
private Double outputcgst;
@JsonProperty("DN_CGST")
private Integer dnCgst;
@JsonProperty("A_CGST")
private Integer aCgst;
@JsonProperty("ITCODE")
private String itcode;
@JsonProperty("TOUTPUTVAT")
private Integer toutputvat;
@JsonProperty("A_TAXAMT")
private Integer aTaxamt;
@JsonProperty("TOUTSGST")
private Double toutsgst;
@JsonProperty("PNAME")
private String pname;
@JsonProperty("VATRT")
private Integer vatrt;
@JsonProperty("SP")
private Double sp;
@JsonProperty("BATCHNO")
private String batchno;
@JsonProperty("DN_TAXAMT")
private Integer dnTaxamt;
@JsonProperty("INVOICENO")
private String invoiceno;
@JsonProperty("DN_SGST")
private Integer dnSgst;
@JsonProperty("PRTYNAME")
private String prtyname;
@JsonProperty("REFERCOD")
private String refercod;
@JsonProperty("BRECNO_C")
private String brecnoC;
@JsonProperty("BRECNO")
private Integer brecno;
@JsonProperty("A_TCOST")
private Integer aTcost;
@JsonProperty("NETRATE")
private Double netrate;
@JsonProperty("TDISCOUNT")
private Integer tdiscount;
@JsonProperty("REBATE")
private Integer rebate;
@JsonProperty("DN_TCOST")
private Integer dnTcost;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("PRINT")
public Integer getPrint() {
return print;
}

@JsonProperty("PRINT")
public void setPrint(Integer print) {
this.print = print;
}

@JsonProperty("DUEDT")
public String getDuedt() {
return duedt;
}

@JsonProperty("DUEDT")
public void setDuedt(String duedt) {
this.duedt = duedt;
}

@JsonProperty("DN_DISCRT")
public Integer getDnDiscrt() {
return dnDiscrt;
}

@JsonProperty("DN_DISCRT")
public void setDnDiscrt(Integer dnDiscrt) {
this.dnDiscrt = dnDiscrt;
}

@JsonProperty("A_DISCRT")
public Integer getADiscrt() {
return aDiscrt;
}

@JsonProperty("A_DISCRT")
public void setADiscrt(Integer aDiscrt) {
this.aDiscrt = aDiscrt;
}

@JsonProperty("SGSTRT")
public Integer getSgstrt() {
return sgstrt;
}

@JsonProperty("SGSTRT")
public void setSgstrt(Integer sgstrt) {
this.sgstrt = sgstrt;
}

@JsonProperty("ITNM")
public String getItnm() {
return itnm;
}

@JsonProperty("ITNM")
public void setItnm(String itnm) {
this.itnm = itnm;
}

@JsonProperty("CO_CODE")
public String getCoCode() {
return coCode;
}

@JsonProperty("CO_CODE")
public void setCoCode(String coCode) {
this.coCode = coCode;
}

@JsonProperty("RETURNED")
public Integer getReturned() {
return returned;
}

@JsonProperty("RETURNED")
public void setReturned(Integer returned) {
this.returned = returned;
}

@JsonProperty("DN_NOFUNIT")
public Integer getDnNofunit() {
return dnNofunit;
}

@JsonProperty("DN_NOFUNIT")
public void setDnNofunit(Integer dnNofunit) {
this.dnNofunit = dnNofunit;
}

@JsonProperty("REFERNAME")
public String getRefername() {
return refername;
}

@JsonProperty("REFERNAME")
public void setRefername(String refername) {
this.refername = refername;
}

@JsonProperty("PMTERMS")
public String getPmterms() {
return pmterms;
}

@JsonProperty("PMTERMS")
public void setPmterms(String pmterms) {
this.pmterms = pmterms;
}

@JsonProperty("TCOST")
public Integer getTcost() {
return tcost;
}

@JsonProperty("TCOST")
public void setTcost(Integer tcost) {
this.tcost = tcost;
}

@JsonProperty("UNITOFMESU")
public String getUnitofmesu() {
return unitofmesu;
}

@JsonProperty("UNITOFMESU")
public void setUnitofmesu(String unitofmesu) {
this.unitofmesu = unitofmesu;
}

@JsonProperty("HSN")
public String getHsn() {
return hsn;
}

@JsonProperty("HSN")
public void setHsn(String hsn) {
this.hsn = hsn;
}

@JsonProperty("CGSTRT")
public Integer getCgstrt() {
return cgstrt;
}

@JsonProperty("CGSTRT")
public void setCgstrt(Integer cgstrt) {
this.cgstrt = cgstrt;
}

@JsonProperty("NOOFUNIT")
public Integer getNoofunit() {
return noofunit;
}

@JsonProperty("NOOFUNIT")
public void setNoofunit(Integer noofunit) {
this.noofunit = noofunit;
}

@JsonProperty("TOUTCGST")
public Double getToutcgst() {
return toutcgst;
}

@JsonProperty("TOUTCGST")
public void setToutcgst(Double toutcgst) {
this.toutcgst = toutcgst;
}

@JsonProperty("TAXAMT")
public Integer getTaxamt() {
return taxamt;
}

@JsonProperty("TAXAMT")
public void setTaxamt(Integer taxamt) {
this.taxamt = taxamt;
}

@JsonProperty("REBATERT")
public Integer getRebatert() {
return rebatert;
}

@JsonProperty("REBATERT")
public void setRebatert(Integer rebatert) {
this.rebatert = rebatert;
}

@JsonProperty("OUTPUTVAT")
public Integer getOutputvat() {
return outputvat;
}

@JsonProperty("OUTPUTVAT")
public void setOutputvat(Integer outputvat) {
this.outputvat = outputvat;
}

@JsonProperty("DISCOUNT")
public Integer getDiscount() {
return discount;
}

@JsonProperty("DISCOUNT")
public void setDiscount(Integer discount) {
this.discount = discount;
}

@JsonProperty("SHIP_ADDRE")
public String getShipAddre() {
return shipAddre;
}

@JsonProperty("SHIP_ADDRE")
public void setShipAddre(String shipAddre) {
this.shipAddre = shipAddre;
}

@JsonProperty("RETURN_QTY")
public Integer getReturnQty() {
return returnQty;
}

@JsonProperty("RETURN_QTY")
public void setReturnQty(Integer returnQty) {
this.returnQty = returnQty;
}

@JsonProperty("INVOICEDT")
public String getInvoicedt() {
return invoicedt;
}

@JsonProperty("INVOICEDT")
public void setInvoicedt(String invoicedt) {
this.invoicedt = invoicedt;
}

@JsonProperty("ADDRESS")
public String getAddress() {
return address;
}

@JsonProperty("ADDRESS")
public void setAddress(String address) {
this.address = address;
}

@JsonProperty("PKSIZE")
public Double getPksize() {
return pksize;
}

@JsonProperty("PKSIZE")
public void setPksize(Double pksize) {
this.pksize = pksize;
}

@JsonProperty("OUTPUTSGST")
public Double getOutputsgst() {
return outputsgst;
}

@JsonProperty("OUTPUTSGST")
public void setOutputsgst(Double outputsgst) {
this.outputsgst = outputsgst;
}

@JsonProperty("A_SGST")
public Integer getASgst() {
return aSgst;
}

@JsonProperty("A_SGST")
public void setASgst(Integer aSgst) {
this.aSgst = aSgst;
}

@JsonProperty("ITEMNM")
public String getItemnm() {
return itemnm;
}

@JsonProperty("ITEMNM")
public void setItemnm(String itemnm) {
this.itemnm = itemnm;
}

@JsonProperty("OUTPUTCGST")
public Double getOutputcgst() {
return outputcgst;
}

@JsonProperty("OUTPUTCGST")
public void setOutputcgst(Double outputcgst) {
this.outputcgst = outputcgst;
}

@JsonProperty("DN_CGST")
public Integer getDnCgst() {
return dnCgst;
}

@JsonProperty("DN_CGST")
public void setDnCgst(Integer dnCgst) {
this.dnCgst = dnCgst;
}

@JsonProperty("A_CGST")
public Integer getACgst() {
return aCgst;
}

@JsonProperty("A_CGST")
public void setACgst(Integer aCgst) {
this.aCgst = aCgst;
}

@JsonProperty("ITCODE")
public String getItcode() {
return itcode;
}

@JsonProperty("ITCODE")
public void setItcode(String itcode) {
this.itcode = itcode;
}

@JsonProperty("TOUTPUTVAT")
public Integer getToutputvat() {
return toutputvat;
}

@JsonProperty("TOUTPUTVAT")
public void setToutputvat(Integer toutputvat) {
this.toutputvat = toutputvat;
}

@JsonProperty("A_TAXAMT")
public Integer getATaxamt() {
return aTaxamt;
}

@JsonProperty("A_TAXAMT")
public void setATaxamt(Integer aTaxamt) {
this.aTaxamt = aTaxamt;
}

@JsonProperty("TOUTSGST")
public Double getToutsgst() {
return toutsgst;
}

@JsonProperty("TOUTSGST")
public void setToutsgst(Double toutsgst) {
this.toutsgst = toutsgst;
}

@JsonProperty("PNAME")
public String getPname() {
return pname;
}

@JsonProperty("PNAME")
public void setPname(String pname) {
this.pname = pname;
}

@JsonProperty("VATRT")
public Integer getVatrt() {
return vatrt;
}

@JsonProperty("VATRT")
public void setVatrt(Integer vatrt) {
this.vatrt = vatrt;
}

@JsonProperty("SP")
public Double getSp() {
return sp;
}

@JsonProperty("SP")
public void setSp(Double sp) {
this.sp = sp;
}

@JsonProperty("BATCHNO")
public String getBatchno() {
return batchno;
}

@JsonProperty("BATCHNO")
public void setBatchno(String batchno) {
this.batchno = batchno;
}

@JsonProperty("DN_TAXAMT")
public Integer getDnTaxamt() {
return dnTaxamt;
}

@JsonProperty("DN_TAXAMT")
public void setDnTaxamt(Integer dnTaxamt) {
this.dnTaxamt = dnTaxamt;
}

@JsonProperty("INVOICENO")
public String getInvoiceno() {
return invoiceno;
}

@JsonProperty("INVOICENO")
public void setInvoiceno(String invoiceno) {
this.invoiceno = invoiceno;
}

@JsonProperty("DN_SGST")
public Integer getDnSgst() {
return dnSgst;
}

@JsonProperty("DN_SGST")
public void setDnSgst(Integer dnSgst) {
this.dnSgst = dnSgst;
}

@JsonProperty("PRTYNAME")
public String getPrtyname() {
return prtyname;
}

@JsonProperty("PRTYNAME")
public void setPrtyname(String prtyname) {
this.prtyname = prtyname;
}

@JsonProperty("REFERCOD")
public String getRefercod() {
return refercod;
}

@JsonProperty("REFERCOD")
public void setRefercod(String refercod) {
this.refercod = refercod;
}

@JsonProperty("BRECNO_C")
public String getBrecnoC() {
return brecnoC;
}

@JsonProperty("BRECNO_C")
public void setBrecnoC(String brecnoC) {
this.brecnoC = brecnoC;
}

@JsonProperty("BRECNO")
public Integer getBrecno() {
return brecno;
}

@JsonProperty("BRECNO")
public void setBrecno(Integer brecno) {
this.brecno = brecno;
}

@JsonProperty("A_TCOST")
public Integer getATcost() {
return aTcost;
}

@JsonProperty("A_TCOST")
public void setATcost(Integer aTcost) {
this.aTcost = aTcost;
}

@JsonProperty("NETRATE")
public Double getNetrate() {
return netrate;
}

@JsonProperty("NETRATE")
public void setNetrate(Double netrate) {
this.netrate = netrate;
}

@JsonProperty("TDISCOUNT")
public Integer getTdiscount() {
return tdiscount;
}

@JsonProperty("TDISCOUNT")
public void setTdiscount(Integer tdiscount) {
this.tdiscount = tdiscount;
}

@JsonProperty("REBATE")
public Integer getRebate() {
return rebate;
}

@JsonProperty("REBATE")
public void setRebate(Integer rebate) {
this.rebate = rebate;
}

@JsonProperty("DN_TCOST")
public Integer getDnTcost() {
return dnTcost;
}

@JsonProperty("DN_TCOST")
public void setDnTcost(Integer dnTcost) {
this.dnTcost = dnTcost;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}