package com.gpch.pdfgenerator.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ItemModel {
	
	private String serialNo;
	private String pname;
	private String hsn;
	private String pack;
	private Integer nop;
	private Double qty;
	private Double rate;
	private Double cgst;
	private Double sgst;
	private Double total;
	private Double valBefTax;
	

}
