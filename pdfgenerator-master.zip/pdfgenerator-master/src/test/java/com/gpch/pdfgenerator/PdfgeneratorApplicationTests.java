package com.gpch.pdfgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfgeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
