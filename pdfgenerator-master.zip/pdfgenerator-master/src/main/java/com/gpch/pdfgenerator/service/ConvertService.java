package com.gpch.pdfgenerator.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gpch.pdfgenerator.model.InvoiceJSONModel;

//import net.iryndin.jdbf.core.DbfMetadata;
import net.iryndin.jdbf.core.DbfRecord;
import net.iryndin.jdbf.reader.DbfReader;


@Service
public class ConvertService {

	@Value("${invoice.filepath}")
	String filePath;
	
	public List<InvoiceJSONModel> convert() throws IOException, ParseException {
	
return readDBF();
		
	}
	
	
	public List<InvoiceJSONModel> readDBF() throws IOException, ParseException {
		List<InvoiceJSONModel> listOfInvoice= new ArrayList<>();
		
		System.out.println(filePath);
		
        Charset stringCharset = Charset.forName("Cp866");
        InputStream dbf = new FileInputStream("/Users/arghaghosh/eclipse-workspace/ReadFromDBF/src/resources/_06.DBF");
        DbfRecord rec;
        try (DbfReader reader = new DbfReader(dbf)) {
           // DbfMetadata meta = reader.getMetadata();
            int recCounter = 0;
            while ((rec = reader.read()) != null) {
                rec.setStringCharset(stringCharset);
                JSONObject json = new JSONObject(rec.toMap());
                
                ObjectMapper  mapper = new ObjectMapper();
                InvoiceJSONModel model=mapper.readValue(json.toString(), InvoiceJSONModel.class);
                listOfInvoice.add(model);
                recCounter++;
            }
            if(recCounter==listOfInvoice.size())
            {
            	System.out.println("Count Matched");
            }
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        finally {
        	dbf.close();
        }
        return listOfInvoice;
    }

}
