package com.gpch.pdfgenerator.model;

import com.opencsv.bean.CsvBindByPosition;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceCSVModel {

	@CsvBindByPosition(position = 0)
	String INVOICENO;
	@CsvBindByPosition(position = 1)
	String INVOICEDT;
	@CsvBindByPosition(position = 2)
	String CO_CODE;
	@CsvBindByPosition(position = 3)
	String PRTYNAME;
	@CsvBindByPosition(position = 4)
	String ADDRESS;
	@CsvBindByPosition(position = 5)
	String SHIP_ADDRE;
	@CsvBindByPosition(position = 6)
	String PARTYVATNO;
	@CsvBindByPosition(position = 7)
	String REFERCOD;
	@CsvBindByPosition(position = 8)
	String REFERNAME;
	@CsvBindByPosition(position = 9)
	String PMTERMS;
	@CsvBindByPosition(position = 10)
	String HSN;
	@CsvBindByPosition(position = 11)
	String ITCODE;
	@CsvBindByPosition(position = 12)
	String DUEDT;
	@CsvBindByPosition(position = 13)
	String ITNM;
	@CsvBindByPosition(position =14)
	String ITEMNM;
	@CsvBindByPosition(position = 15)
	String PNAME;
	@CsvBindByPosition(position = 16)
	String PKSIZE;
	@CsvBindByPosition(position = 17)
	String BATCHNO;
	@CsvBindByPosition(position = 18)
	String BRECNO_C;
	@CsvBindByPosition(position = 19)
	String BRECNO;
	@CsvBindByPosition(position = 20)
	String SP;
	@CsvBindByPosition(position = 21)
	String NOOFUNIT;
	@CsvBindByPosition(position = 22)
	String RETURNED;
	@CsvBindByPosition(position = 23)
	String NETRATE;
	@CsvBindByPosition(position = 24)
	String VATRT;
	@CsvBindByPosition(position = 25)
	String CGSTRT;
	@CsvBindByPosition(position = 26)
	String SGSTRT;
	@CsvBindByPosition(position = 27)
	String UNITOFMESU;
	@CsvBindByPosition(position = 28)
	String REBATERT;
	@CsvBindByPosition(position = 29)
	String REBATE;
	@CsvBindByPosition(position = 30)
	String DISCOUNT;
	@CsvBindByPosition(position = 31)
	String TDISCOUNT;
	@CsvBindByPosition(position = 32)
	String TAXAMT;
	@CsvBindByPosition(position = 33)
	String OUTPUTCGST;
	@CsvBindByPosition(position = 34)
	String OUTPUTSGST;
	@CsvBindByPosition(position = 35)
	String OUTPUTVAT;
	@CsvBindByPosition(position = 36)
	String TOUTPUTVAT;
	@CsvBindByPosition(position = 37)
	String TOUTCGST;
	@CsvBindByPosition(position = 38)
	String TOUTSGST;
	@CsvBindByPosition(position = 39)
	String TCOST;
	@CsvBindByPosition(position = 40)
	String PRINT;
	@CsvBindByPosition(position = 41)
	String PYMT_DT;
	@CsvBindByPosition(position = 42)
	String DN_DISCRT;
	@CsvBindByPosition(position = 43)
	String DN_TAXAMT;
	@CsvBindByPosition(position = 44)
	String DN_CGST;
	@CsvBindByPosition(position = 45)
	String DN_SGST;
	@CsvBindByPosition(position = 46)
	String DN_TCOST;
	@CsvBindByPosition(position = 47)
	String RETURN_QTY;
	@CsvBindByPosition(position = 48)
	String DN_NOFUNIT;
	@CsvBindByPosition(position = 49)
	String A_DISCRT;
	@CsvBindByPosition(position = 50)
	String A_TAXAMT;
	@CsvBindByPosition(position = 51)
	String A_CGST;
	@CsvBindByPosition(position = 52)
	String A_SGST;
	@CsvBindByPosition(position = 53)
	String A_TCOST;	
	
	
}
