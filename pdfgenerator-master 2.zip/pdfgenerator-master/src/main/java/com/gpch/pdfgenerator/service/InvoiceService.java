package com.gpch.pdfgenerator.service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gpch.pdfgenerator.model.FinalInvoiceModel;
import com.gpch.pdfgenerator.model.InvoiceCSVModel;
import com.gpch.pdfgenerator.model.InvoiceJSONModel;
import com.gpch.pdfgenerator.model.ItemModel;
import com.opencsv.bean.CsvToBeanBuilder;

@Service
public class InvoiceService {

    @Autowired
    private ConvertService convertService;
    
    public List<FinalInvoiceModel> getInvoices(){
    	List<InvoiceJSONModel> allInvoices= new ArrayList<>();
    	
    	try {
			allInvoices=convertService.convert();
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   	

    List<FinalInvoiceModel> listWithoutDuplicates =  createFinalInvoice(allInvoices).stream().distinct().collect(Collectors.toList());
    	
		return listWithoutDuplicates;
    	
    	
    }
    
    public List<FinalInvoiceModel> createFinalInvoice(List<InvoiceJSONModel> invoices)
    {
    	List<FinalInvoiceModel> allInvoices= new ArrayList<>();
    	for (InvoiceJSONModel invoiceItem : invoices)
    	{
    		FinalInvoiceModel invoice= new FinalInvoiceModel();
    		invoice.setInvoiceNo(invoiceItem.getInvoiceno());
    		invoice.setDate(invoiceItem.getInvoicedt());
    		invoice.setCname(invoiceItem.getPrtyname());  
    		invoice.setCaddress(invoiceItem.getAddress());   
    		//invoice.setCgstno(invoiceItem.getp);   
    		invoice.setPaymentMode(invoiceItem.getPmterms());
    	
    		final List<ItemModel> invItems= new ArrayList<>();
    		Double sgst = Double.valueOf(0) ;
    		Double cgst = Double.valueOf(0) ;
    		Double total = Double.valueOf(0) ;
    		Double totNop = Double.valueOf(0) ;
    		Double totVBP = Double.valueOf(0) ;
    		Double totalqty = Double.valueOf(0) ;
    		
    		List<InvoiceJSONModel> allIteminInvoice=invoices.stream().filter(invItem -> invItem.getInvoiceno().equalsIgnoreCase(invoiceItem.getInvoiceno())).collect(Collectors.toList());
    		int serial=1;
    		for(InvoiceJSONModel itemList : allIteminInvoice)
    		{ ItemModel item= new ItemModel();
    			item.setSerialNo(serial++ + "");   			
    			item.setPname(itemList.getItemnm()+ " " +itemList.getPname());
    			item.setHsn(itemList.getHsn());
    			item.setPack(itemList.getPksize() + " " + itemList.getUnitofmesu());
    			item.setNop(itemList.getNoofunit());
    			item.setQty(itemList.getNoofunit()*itemList.getPksize());  
    			item.setValBefTax(Double.parseDouble(new DecimalFormat("##.##").format(itemList.getNetrate()/itemList.getNoofunit())));  			
    			item.setRate(Double.valueOf(itemList.getNetrate()));
    			item.setCgst(Double.valueOf(itemList.getOutputcgst()));
    			item.setSgst(Double.valueOf(itemList.getOutputsgst()));
    			item.setTotal(Double.valueOf(itemList.getTcost()));
    			invItems.add(item);
    			totVBP += item.getValBefTax();
    			totalqty += item.getQty();
    			totNop += item.getNop();
    			total += item.getTotal();
    			cgst += item.getCgst();
    			sgst += item.getSgst();
    		
    		}
    		invoice.setTotalNop(Double.parseDouble(new DecimalFormat("##.##").format(totNop)));
    		invoice.setTotalvbt(Double.parseDouble(new DecimalFormat("##.##").format(totVBP)));
    		invoice.setTotqty(Double.parseDouble(new DecimalFormat("##.##").format(totalqty)));
    		invoice.setItems(invItems);   
    		invoice.setTotal(Double.parseDouble(new DecimalFormat("##.##").format(total)));    	
    		invoice.setTotalCgst(Double.parseDouble(new DecimalFormat("##.##").format(cgst))); 
    		invoice.setTotalSgst(Double.parseDouble(new DecimalFormat("##.##").format(sgst))); 
    		
    		allInvoices.add(invoice) ;
    		}
    	
    	return allInvoices;
    	
    }
    
    
}
